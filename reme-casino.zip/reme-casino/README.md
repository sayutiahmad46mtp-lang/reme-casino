# Reme Casino APK

## Cara Build APK via GitHub Actions

### Langkah 1 — Buat repo GitHub
1. Buka github.com → login
2. Klik **"New repository"**
3. Nama repo: `reme-casino`
4. Pilih **Public**
5. Klik **Create repository**

### Langkah 2 — Upload semua file ini
1. Di halaman repo yang baru dibuat, klik **"uploading an existing file"**
2. Upload SEMUA file dan folder dari folder ini
   - Pastikan struktur folder tetap sama!
3. Klik **"Commit changes"**

### Langkah 3 — Jalankan Build
1. Klik tab **"Actions"** di repo
2. Klik workflow **"Build APK"**
3. Klik **"Run workflow"** → **"Run workflow"**
4. Tunggu sekitar 5-10 menit

### Langkah 4 — Download APK
1. Setelah build selesai (centang hijau ✅)
2. Klik workflow yang sudah selesai
3. Scroll ke bawah → **"Artifacts"**
4. Download **"reme-casino-apk"**
5. Extract zip → install `app-release-unsigned.apk`

### Catatan Install
- Aktifkan **"Install from unknown sources"** di Settings HP
- Settings → Security → Unknown Sources → ON

---
Game: Reme Casino  
Version: 1.0
